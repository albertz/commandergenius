Replaces all Igor's dialog quotes with "Test quote XXX"
