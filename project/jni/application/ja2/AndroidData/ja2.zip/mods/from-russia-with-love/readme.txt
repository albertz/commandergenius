There is a little something waiting for you in Omerta.

= from Russia with love

Note:
 Please start the new game in "Tons of Guns" mode.
