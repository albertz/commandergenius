This folder contains modifications to the original game.
Every mod has its own license.
