Free Heroes2 Engine

Prerequisites:

You need to have these libraries (with equivalent devel versions) to build fHeroes2:

- SDL

optional library:
- SDL_mixer (play music: internal midi or external ogg tracks) or build WITHOUT_MIXER
- SDL_image (loading external sprites, create screenshot in png format) or build WITHOUT_IMAGE
- SDL_ttf (unicode support) or build WITHOUT_UNICODE
- SDL_net or build WITHOUT_NETWORK
- libogg
- libpng
- gettext

SDL libraries can be found at http://www.libsdl.org .
Sourcecode you can get it here: http://sourceforge.net/projects/fheroes2/
And translations: http://translations.launchpad.net/fheroes2

For play:
Copy origin data/*.agg in to data directory.
Copy maps files (*.mp2) in to maps directory.

Hot keys:
all hotkeys may be redefined (see fheroes2.key)
