list tracks:
02 Battle (1).ogg
03 Battle (2).ogg
04 Battle (3).ogg
05 Barbarian Castle.ogg
06 Sorceress Castle.ogg
07 Warlock Castle.ogg
08 Knight Castle.ogg
09 Necromancer Castle.ogg
10 Wizard Castle.ogg
11 Lava Theme.ogg
12 Wasteland Theme.ogg
13 Desert Theme.ogg
14 Snow Theme.ogg
15 Swamp Theme.ogg
16 Beach Theme.ogg
17 Dirt Theme.ogg
18 Grass Theme.ogg
19 Lost Game.ogg
20 Week (1).ogg
21 Week (2) Month (1).ogg
22 Month (2).ogg
23 Map Puzzle.ogg
24 Roland's Campaign.ogg
25.ogg
25.ogg
25.ogg
25.ogg
25.ogg
25.ogg
25.ogg
25.ogg
25.ogg
25.ogg
25.ogg
25.ogg
25.ogg
25.ogg
25.ogg
40.ogg
41.ogg
42 Main Menu.ogg
43 Scenario Victory.ogg
