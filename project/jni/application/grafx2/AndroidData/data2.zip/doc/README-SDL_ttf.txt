The following files:

	SDL_ttf.dll
	libfreetype-6.dll

are the runtime environment for the library SDL_ttf 2.0 by Sam Lantiga.

This library is distributed under the terms of the GNU LGPL license:
http://www.gnu.org/copyleft/lesser.html

The source is available from the libraries page at the SDL website:
http://www.libsdl.org/
