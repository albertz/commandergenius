The following file

	SDL_image.dll

is the runtime environment for the library SDL_image 1.2.10 by Sam Lantiga and Mattias Engdeg�rd.

This library is distributed under the terms of the GNU LGPL license:
http://www.gnu.org/copyleft/lesser.html

The source is available from the libraries page at the SDL website:
http://www.libsdl.org/

=========================

Compiled by yrizoud on 16/06/2010 with static builds of :
	libjpeg (JPEG library http://www.ijg.org/ release 6b of 27-Mar-1998 : jpegsr6.zip)
	libtiff (TIFF library ftp://ftp.sgi.com/graphics/tiff/ : tiff-v3.4-tar.gz)
And dynamic version of :
	libpng (http://www.libpng.org/pub/png/libpng.html) v1.4.2 --> libpng14-14.dll requirement
