# this file is executed at gemrb startup, for the Console
from ie_stats import *
